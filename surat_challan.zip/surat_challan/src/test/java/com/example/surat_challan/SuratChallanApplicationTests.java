package com.example.surat_challan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuratChallanApplicationTests {

	@Test
	void contextLoads() {
	}

}
